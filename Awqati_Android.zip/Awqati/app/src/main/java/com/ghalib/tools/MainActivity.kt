package com.ghalib.tools

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var content: FrameLayout
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private val gravity = FloatArray(3)
    private val geomagnetic = FloatArray(3)
    private var hasGravity = false
    private var hasMagnetic = false
    private var headingText: TextView? = null
    private var directionText: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        val nav = findViewById<BottomNavigationView>(R.id.navigation)
        nav.setOnItemSelectedListener { item ->
            when (item.itemId) { R.id.home -> showHome(); R.id.compass -> showCompass(); R.id.tools -> showTools() }
            true
        }
        showHome()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    }

    private fun showHome() {
        val v = layoutInflater.inflate(R.layout.home, content, false); content.removeAllViews(); content.addView(v)
        val now = Calendar.getInstance()
        val g = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.ENGLISH).format(now.time)
        v.findViewById<TextView>(R.id.gregorian).text = g
        val ic = android.icu.util.IslamicCalendar(android.icu.util.IslamicCalendar.UMALQURA)
        ic.timeInMillis = now.timeInMillis
        v.findViewById<TextView>(R.id.hijri).text = "${ic.get(Calendar.DAY_OF_MONTH)} / ${ic.get(Calendar.MONTH)+1} / ${ic.get(Calendar.YEAR)} هـ"
        v.findViewById<Button>(R.id.convert).setOnClickListener {
            val input = v.findViewById<EditText>(R.id.dateInput).text.toString().trim()
            val out = v.findViewById<TextView>(R.id.result)
            try {
                val parts = input.split("-"); require(parts.size == 3)
                val c = Calendar.getInstance().apply { set(parts[0].toInt(), parts[1].toInt()-1, parts[2].toInt(), 12, 0, 0) }
                val h = android.icu.util.IslamicCalendar(android.icu.util.IslamicCalendar.UMALQURA); h.timeInMillis = c.timeInMillis
                out.text = "الهجري: ${h.get(Calendar.DAY_OF_MONTH)} / ${h.get(Calendar.MONTH)+1} / ${h.get(Calendar.YEAR)} هـ"
            } catch (e: Exception) { out.text = "أدخل التاريخ بهذا الشكل: YYYY-MM-DD" }
        }
    }

    private fun showCompass() {
        val v = layoutInflater.inflate(R.layout.compass, content, false); content.removeAllViews(); content.addView(v)
        headingText = v.findViewById(R.id.heading); directionText = v.findViewById(R.id.direction)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI)
    }

    private fun showTools() {
        sensorManager.unregisterListener(this)
        val v = layoutInflater.inflate(R.layout.tools, content, false); content.removeAllViews(); content.addView(v)
        v.findViewById<Button>(R.id.measure).setOnClickListener {
            val n = v.findViewById<EditText>(R.id.value).text.toString().toDoubleOrNull()
            v.findViewById<TextView>(R.id.measureResult).text = if (n == null) "أدخل رقمًا صحيحًا" else String.format(Locale.US, "%.2f m\n%.2f cm\n%.2f ft\n%.2f in", n, n*100, n*3.28084, n*39.3701)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) { System.arraycopy(event.values,0,gravity,0,3); hasGravity=true }
        if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) { System.arraycopy(event.values,0,geomagnetic,0,3); hasMagnetic=true }
        if (hasGravity && hasMagnetic) {
            val r = FloatArray(9); val i = FloatArray(9)
            if (SensorManager.getRotationMatrix(r,i,gravity,geomagnetic)) {
                val o = FloatArray(3); SensorManager.getOrientation(r,o)
                var deg = Math.toDegrees(o[0].toDouble()).toFloat(); if (deg < 0) deg += 360f
                headingText?.text = "${deg.toInt()}°"
                directionText?.text = when (deg) { in 337.5f..360f, in 0f..22.5f -> "شمال N"; in 22.5f..67.5f -> "شمال شرقي NE"; in 67.5f..112.5f -> "شرق E"; in 112.5f..157.5f -> "جنوب شرقي SE"; in 157.5f..202.5f -> "جنوب S"; in 202.5f..247.5f -> "جنوب غربي SW"; in 247.5f..292.5f -> "غرب W"; else -> "شمال غربي NW" }
            }
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onResume() { super.onResume(); if (headingText != null) { sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI); sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI) } }
    override fun onPause() { super.onPause(); sensorManager.unregisterListener(this) }
}
